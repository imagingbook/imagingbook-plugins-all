package _ICP_Obsolete.geom.points;

import java.util.List;

public class AffineFitter implements LeastSquaresFitter {

	@Override
	public void fit(List<double[]> X, List<double[]> Y) {
		// TODO Auto-generated method stub
		
	}

}
