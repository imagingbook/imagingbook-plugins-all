package _ICP_Obsolete.geom.points;

import java.util.List;

@Deprecated
public interface LeastSquaresFitter {
	
	public void fit(List<double[]> X, List<double[]> Y);

}
